<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ContactMessage extends Model
{
    protected $fillable = [
        'name', 'email', 'phone', 'subject', 'message',
        'ip_address', 'user_agent', 'status', 'read_at',
    ];

    protected function casts(): array
    {
        return ['read_at' => 'datetime'];
    }

    public function markAsRead(): void
    {
        if ($this->status !== 'read') {
            $this->forceFill(['status' => 'read', 'read_at' => now()])->save();
        }
    }
}
